#ifndef LIST_H
#define LIST_H
#include <string>

class Sorted_List{
  public:
    Sorted_List();
    Sorted_List(Sorted_List const & other); //deep copy
    Sorted_List(Sorted_List && other);
    Sorted_List & operator =(Sorted_List const & other);
    Sorted_List & operator =(Sorted_List && other);
    ~Sorted_List();

    void push(int const & i); //insert
    bool is_empty() const;    //Tested
    void remove(int val);     //Tested
    void insert(int val);
    int pop();
    int size();               //Tested
    //void print_list();        //Test_case?
    std::string print_list();

  private:
    struct Node
    {
      int value{};
      Node * next{};
    };
    Node * head{};
    Node * copy(Node const *n)const;
};

#endif
