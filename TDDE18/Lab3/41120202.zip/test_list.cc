// This test program uses a test framework supporting TDD and BDD.
// You are not required to use the framework, but encouraged to.
// Code:
// https://github.com/philsquared/Catch.git
// Documentation:
// https://github.com/philsquared/Catch/blob/master/docs/tutorial.md

// You ARE however required to implement all test cases outlined here,
// even if you do it by way of your own function for each case.  You
// are recommended to solve the cases in order, and rerun all tests
// after you modify your code.

// This define lets Catch create the main test program
// (Must be in only one place!)
#define CATCH_CONFIG_MAIN
#include "catch.hpp"
#include "Sorted_List.h"

#include <random>

//=======================================================================
// Test cases
//=======================================================================

TEST_CASE( "Create an empty list" ) {
  Sorted_List l{};
  // Testing
  REQUIRE( l.is_empty() == true );
  REQUIRE( l.size() == 0 );
}

// It is your job to create new test cases and fully test your Sorted_List class

TEST_CASE( "Insert and Remove elements" ) {
  Sorted_List l{};

  std::string str{"1991->1988->1986->1984->1983->end\n"};
  l.insert(1983);;
  l.insert(1984);
  l.insert(1991);
  l.insert(1988);
  l.insert(1986);
  //std::cout << l.print_list() << std::endl;
  //std::cout << str << std::endl;

  //Intentar eliminar un elemento que no existe
  REQUIRE( str.compare(l.print_list()) == 0 );
  l.remove(1986);
  str = "1991->1988->1984->1983->end\n";
  REQUIRE( str.compare(l.print_list()) == 0 );
  l.remove(1991);
  str = "1988->1984->1983->end\n";
  REQUIRE( str.compare(l.print_list()) == 0 );
  l.remove(1983);
  str = "1988->1984->end\n";
  REQUIRE( str.compare(l.print_list()) == 0 );
  l.remove(1984);
  str = "1988->end\n";
  REQUIRE( str.compare(l.print_list()) == 0 );
  l.remove(1988);
  REQUIRE( l.is_empty());


}

TEST_CASE( "Create a copy" ) {
  Sorted_List l{};
  l.insert(1983);
  l.insert(1984);
  l.insert(1986);

  Sorted_List copy{l};
  REQUIRE( copy.size() == 3 );
  REQUIRE( l.size() == 3 );
}
/*
TEST_CASE( "Print elements" ) {
  Sorted_List l{};
  std::stringstream ss{};
  std::string str{"1986->1984->1983->end"};

  l.push(1983);
  l.push(1984);
  l.push(1986);

  ss << l.print_list();
  std::string sstr = ss.str();
  REQUIRE(str.compare(sstr) == 0);
}
*/
